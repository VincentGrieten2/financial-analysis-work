Financial Analysis Tool v1.0.1
============================

This package contains the Financial Analysis Tool, which helps you extract financial data from PDF statements and organize it into standardized Excel format.

Files Included:
- Financial_Analysis.exe: The main application
- README.txt: This file
- verification.txt: Contains file hashes for security verification

Security Notice
--------------
When running this application for the first time, you may receive security warnings. This is normal because the application is not digitally signed. The application is completely safe to use, and you can verify this by:

1. Checking that the file hash matches the one in verification.txt
2. Reviewing the source code at: https://github.com/VincentGrieten2/financial-analysis-work
3. Building the application yourself from source

Running the Application
----------------------
1. If Windows shows a "Windows protected your PC" message:
   - Click "More info"
   - Click "Run anyway"

2. If your antivirus blocks the file:
   - Add the application folder to your antivirus exclusions
   - Or temporarily disable real-time scanning while running the application

3. The application will create a log file (parser.log) in the same directory

Support
-------
If you encounter any issues, please:
1. Check the parser.log file for error messages
2. Report issues on our GitHub page
3. Contact your administrator for support

Thank you for using the Financial Analysis Tool! 